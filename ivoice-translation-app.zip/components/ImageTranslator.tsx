
import React, { useState, useRef, useEffect } from 'react';
import { SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface ImageTranslatorProps {
  onTranslate: (base64Image: string, mimeType: string) => void;
  isLoading: boolean;
  disabled?: boolean;
  motherLangCode: SupportedLanguageCode;
}

const ImageTranslator: React.FC<ImageTranslatorProps> = ({ onTranslate, isLoading, disabled, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        setPreviewUrl(null);
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
      alert('Could not access camera. Please check permissions.');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setPreviewUrl(dataUrl);
        stopCamera();
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPreviewUrl(result);
        stopCamera();
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTranslate = () => {
    if (previewUrl) {
      const base64Data = previewUrl.split(',')[1];
      const mimeType = previewUrl.split(';')[0].split(':')[1];
      onTranslate(base64Data, mimeType);
    }
  };

  const reset = () => {
    setPreviewUrl(null);
    stopCamera();
  };

  return (
    <div className="flex flex-col gap-4 w-full animate-in fade-in duration-300">
      <div className="relative bg-slate-900/50 border-2 border-slate-700 rounded-[2rem] overflow-hidden aspect-video flex items-center justify-center group shadow-inner">
        {isCameraActive ? (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            className="w-full h-full object-cover"
          />
        ) : previewUrl ? (
          <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
        ) : (
          <div className="flex flex-col items-center gap-4 text-slate-500 px-4 text-center">
            <svg className="w-16 h-16 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <p className="font-medium">{t.capture_hint}</p>
          </div>
        )}

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4">
          {!isCameraActive && !previewUrl && (
            <>
              <button
                onClick={startCamera}
                disabled={isLoading || disabled}
                className="bg-blue-600 hover:bg-blue-500 text-white p-4 rounded-full shadow-xl transition-all active:scale-95"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                </svg>
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading || disabled}
                className="bg-slate-800 hover:bg-slate-700 text-white p-4 rounded-full shadow-xl transition-all active:scale-95 border border-slate-700"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
              </button>
            </>
          )}

          {isCameraActive && (
            <button
              onClick={captureImage}
              className="bg-white text-slate-900 p-5 rounded-full shadow-xl transition-all active:scale-90 animate-pulse"
            >
              <div className="w-4 h-4 rounded-full bg-red-500"></div>
            </button>
          )}

          {previewUrl && !isLoading && (
            <div className="flex items-center gap-3">
              <button
                onClick={reset}
                className="bg-slate-800/80 backdrop-blur-md text-white px-5 py-2.5 rounded-xl border border-slate-700 transition-all hover:bg-slate-700"
              >
                {t.retry}
              </button>
              <button
                onClick={handleTranslate}
                className="bg-blue-600 text-white px-8 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 font-bold transition-all hover:bg-blue-500 active:scale-95"
              >
                {t.translate_photo}
              </button>
            </div>
          )}
        </div>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />
      <canvas ref={canvasRef} className="hidden" />

      {isLoading && (
        <div className="flex items-center justify-center gap-3 text-blue-400 font-bold py-2">
          <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          {t.scanning}
        </div>
      )}
    </div>
  );
};

export default ImageTranslator;
