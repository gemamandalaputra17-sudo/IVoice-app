
import React, { useState } from 'react';
import { TranslationResult, LanguageOption, SupportedLanguageCode } from '../types';
import { SUPPORTED_LANGUAGES, I18N } from '../constants';

interface TranslationViewProps {
  result: TranslationResult | null;
  error?: string | null;
  targetLang: LanguageOption;
  onPlay: (text: string, locale: string) => void;
  onClear: () => void;
  motherLangCode: SupportedLanguageCode;
}

const TranslationView: React.FC<TranslationViewProps> = ({ result, error, targetLang, onPlay, onClear, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;
  const [copied, setCopied] = useState(false);

  // Error State UI - Highly Prominent
  if (error) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-red-500/5 rounded-[3rem] border-2 border-red-500/20 min-h-[240px] text-center animate-in fade-in zoom-in-95 duration-300">
        <div className="p-5 bg-red-500/10 rounded-full mb-6 border border-red-500/20 shadow-lg shadow-red-500/10">
          <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h4 className="text-white font-black text-lg mb-2">Translation Failed</h4>
        <p className="text-red-400 font-medium text-sm max-w-sm mx-auto leading-relaxed">
          {error}
        </p>
        <button
          onClick={onClear}
          className="mt-6 px-6 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-black uppercase tracking-widest rounded-xl transition-all active:scale-95 border border-red-500/20"
        >
          {t.dismiss}
        </button>
      </div>
    );
  }

  if (!result) return (
    <div className="flex-1 flex flex-col items-center justify-center p-12 bg-slate-900/20 rounded-[3rem] border-2 border-dashed border-slate-800/50 min-h-[240px] text-center group">
      <div className="p-6 bg-slate-800/30 rounded-full mb-6 group-hover:bg-slate-800/50 transition-all">
        <svg className="w-12 h-12 text-slate-700 group-hover:text-slate-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        </svg>
      </div>
      <p className="text-slate-600 font-black uppercase tracking-[0.3em] text-[10px]">{t.empty_hint}</p>
    </div>
  );

  const detectedLang = SUPPORTED_LANGUAGES.find(
    l => l.code === result.detected_language.toLowerCase()
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(result.translated_text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-4 w-full animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-end px-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
            {t.detected}: <span className="text-slate-300">{detectedLang ? detectedLang.nativeName : result.detected_language.toUpperCase()}</span>
          </span>
        </div>
        <button
          onClick={onClear}
          className="text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-white transition-all flex items-center gap-2 px-4 py-2 bg-slate-900/50 border border-slate-800 rounded-xl hover:bg-slate-800 active:scale-95"
        >
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
          {t.dismiss}
        </button>
      </div>
      
      <div className="flex flex-col gap-4 w-full">
        {/* Source Content Preview */}
        <div className="bg-slate-900/50 p-6 rounded-[2rem] border border-slate-800 shadow-inner group transition-all">
          <p className="text-lg leading-relaxed text-slate-400 font-medium italic group-hover:text-slate-300 transition-colors">
            "{result.original_text}"
          </p>
        </div>

        {/* Translation Card */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[3rem] shadow-2xl relative overflow-hidden group">
          {/* Background Highlight */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 blur-[80px] -mr-32 -mt-32 pointer-events-none group-hover:bg-white/20 transition-all duration-700"></div>
          
          <div className="flex items-start justify-between mb-8 relative z-10">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-3">
                <span className="text-3xl filter drop-shadow-lg">{targetLang.flag}</span>
                <span className="text-sm font-black text-white uppercase tracking-widest drop-shadow-sm">{targetLang.nativeName}</span>
              </div>
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={handleCopy}
                className={`w-14 h-14 backdrop-blur-md text-white rounded-[1.25rem] flex items-center justify-center shadow-xl transition-all active:scale-90 border border-white/10 ${copied ? 'bg-green-500' : 'bg-white/10 hover:bg-white/20'}`}
              >
                {copied ? (
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                  </svg>
                )}
              </button>
              <button 
                onClick={() => onPlay(result.translated_text, targetLang.ttsLocale)}
                className="w-14 h-14 bg-white text-blue-600 rounded-[1.25rem] flex items-center justify-center shadow-2xl shadow-blue-900/20 active:scale-90 transition-all hover:bg-blue-50 border border-white/20"
              >
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
                </svg>
              </button>
            </div>
          </div>
          
          <div className="space-y-4 relative z-10">
            <p className="text-4xl font-black text-white leading-[1.1] tracking-tight selection:bg-white/30">
              {result.translated_text}
            </p>
            {result.phonetic && (
              <div className="flex items-center gap-2 group/phonetic">
                <span className="text-[10px] font-black text-blue-200 uppercase tracking-widest">Phonetic:</span>
                <p className="text-base text-blue-100 font-mono bg-white/10 px-4 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm">
                  {result.phonetic}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TranslationView;
