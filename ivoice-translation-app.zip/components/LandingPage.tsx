
import React from 'react';
import { I18N } from '../constants';
import { SupportedLanguageCode } from '../types';

interface LandingPageProps {
  onSignIn: () => void;
  onSignUp: () => void;
  motherLangCode: SupportedLanguageCode;
}

const LandingPage: React.FC<LandingPageProps> = ({ 
  onSignIn, 
  onSignUp, 
  motherLangCode
}) => {
  const t = I18N[motherLangCode] || I18N.en;

  const handleGoPremium = () => {
    window.open('https://www.paypal.com/ncp/payment/2KLDH9E8HAGPJ', '_blank');
  };

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col relative overflow-x-hidden selection:bg-blue-500/30 text-slate-200">
      {/* Dynamic Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[70%] h-[70%] bg-indigo-600/10 blur-[150px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-blue-600/10 blur-[150px] rounded-full"></div>
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-emerald-500/5 blur-[120px] rounded-full"></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.15] mix-blend-overlay"></div>
      </div>

      {/* Floating Pill Navigation */}
      <header className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-3rem)] max-w-4xl">
        <nav className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-full px-6 py-3 flex justify-between items-center shadow-2xl shadow-black/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945" />
              </svg>
            </div>
            <span className="text-lg font-black tracking-tighter text-white">IVoice</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={onSignIn} className="text-sm font-bold text-slate-400 hover:text-white transition-colors">{t.sign_in}</button>
            <button 
              onClick={onSignUp}
              className="px-5 py-2 bg-white text-slate-950 text-sm font-black rounded-full hover:bg-blue-50 transition-all active:scale-95 shadow-lg"
            >
              {t.start_now}
            </button>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 pt-32 pb-20 px-6 max-w-7xl mx-auto w-full">
        <div className="flex flex-col items-center text-center mb-24">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full mb-8 animate-in fade-in slide-in-from-top-4 duration-700">
             <span className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
             </span>
             <span className="text-blue-400 text-[10px] font-black uppercase tracking-[0.3em]">{t.auto_detect}</span>
          </div>

          <h1 className="text-6xl sm:text-8xl md:text-9xl font-black text-white leading-[0.85] tracking-tighter mb-8 max-w-5xl animate-in fade-in slide-in-from-bottom-8 duration-1000">
            Break the <span className="text-transparent bg-clip-text bg-gradient-to-b from-slate-100 to-slate-500">Silence</span> globally.
          </h1>

          <p className="text-slate-400 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed mb-12 animate-in fade-in duration-1000 delay-300">
            Real-time visual and vocal intelligence. IVoice translates the world around you with zero configuration and infinite precision.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-4 animate-in fade-in zoom-in duration-1000 delay-500">
            <button 
              onClick={onSignUp}
              className="group relative px-10 py-5 bg-white text-slate-950 font-black text-lg rounded-2xl hover:scale-105 transition-all active:scale-95 shadow-[0_20px_40px_-10px_rgba(255,255,255,0.2)] flex items-center gap-3 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/10 to-blue-400/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
              <span>{t.start_now}</span>
              <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
            <button 
              onClick={handleGoPremium}
              className="px-10 py-5 bg-white/5 border border-white/10 text-white font-bold text-lg rounded-2xl hover:bg-white/10 transition-all active:scale-95 backdrop-blur-md"
            >
              See Pricing
            </button>
          </div>
        </div>

        {/* Feature Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-32">
          <div className="md:col-span-2 bg-white/[0.02] border border-white/5 p-12 rounded-[3rem] hover:bg-white/[0.04] transition-all group overflow-hidden relative">
            <div className="relative z-10">
              <div className="bg-blue-600/10 w-16 h-16 rounded-2xl flex items-center justify-center text-blue-400 mb-8 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-500">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h3 className="text-4xl font-black text-white mb-4">Neural Voice Synthesis</h3>
              <p className="text-slate-400 text-lg max-w-lg leading-relaxed">
                Experience crystal-clear translation with human-like prosody. IVoice doesn't just translate words; it translates emotion and intent across 8 major languages.
              </p>
            </div>
            <div className="absolute bottom-[-10%] right-[-10%] w-64 h-64 bg-blue-500/10 blur-[80px] rounded-full group-hover:bg-blue-500/20 transition-all"></div>
          </div>

          <div className="bg-white/[0.02] border border-white/5 p-10 rounded-[3rem] hover:bg-white/[0.04] transition-all group">
            <div className="bg-emerald-600/10 w-14 h-14 rounded-2xl flex items-center justify-center text-emerald-400 mb-8 group-hover:scale-110 transition-all">
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              </svg>
            </div>
            <h3 className="text-2xl font-black text-white mb-4">Visual Intelligence</h3>
            <p className="text-slate-400 leading-relaxed font-medium">
              Point your camera at any sign or menu. Our vision engine extracts and translates text instantly.
            </p>
          </div>
        </div>

        {/* Highlighted Premium Section */}
        <div className="relative p-1 bg-gradient-to-br from-yellow-500/50 via-yellow-200/50 to-yellow-600/50 rounded-[4rem] mb-32 group shadow-[0_40px_100px_-20px_rgba(212,175,55,0.2)]">
          <div className="bg-[#0a0a0a] rounded-[3.9rem] p-12 md:p-20 relative overflow-hidden">
            {/* Holographic shimmer */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-2000 pointer-events-none"></div>
            
            <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
              <div className="flex-1 text-left">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-yellow-500/10 border border-yellow-500/20 rounded-full mb-8">
                   <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 24 24">
                     <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                   </svg>
                   <span className="text-yellow-500 text-[10px] font-black uppercase tracking-[0.3em]">The Premium Experience</span>
                </div>
                
                <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter mb-8 leading-[0.9]">
                  Travel Without <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-yellow-600 italic">Connections.</span>
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                   {/* Main Offline Feature Highlight */}
                   <div className="md:col-span-2 bg-white/5 border border-white/10 rounded-[2.5rem] p-8 flex gap-6 items-start hover:bg-white/10 transition-all">
                      <div className="w-16 h-16 bg-yellow-500/10 rounded-[1.5rem] flex items-center justify-center text-yellow-500 flex-shrink-0">
                         <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 002 2h2.945" />
                         </svg>
                      </div>
                      <div>
                         <h4 className="text-xl font-black text-white mb-2 uppercase tracking-tight">Full Offline Mode</h4>
                         <p className="text-slate-400 text-sm leading-relaxed">
                            Download neural language packs for English, Indonesian, Spanish, Chinese, and more. 
                            Communicate basic needs and survival phrases deep in the mountains or high in the air—no cellular data required.
                         </p>
                      </div>
                   </div>

                   {[
                    { title: "Unlimited Usage", text: t.premium_feature_1, icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
                    { title: "HD Voice Quality", text: t.premium_feature_2, icon: 'M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7' },
                    { title: "Zero Interruptions", text: t.premium_feature_3, icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6' },
                    { title: "Visual History", text: "Save and search past scans.", icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' }
                  ].map((item, i) => (
                    <div key={i} className="flex flex-col gap-3 group/item">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-yellow-500/10 flex items-center justify-center text-yellow-500 group-hover/item:scale-110 transition-transform">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={item.icon} />
                          </svg>
                        </div>
                        <span className="text-white font-black text-xs uppercase tracking-widest">{item.title}</span>
                      </div>
                      <p className="text-slate-500 text-sm font-medium pl-14">{item.text}</p>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={handleGoPremium}
                  className="w-full sm:w-auto px-12 py-6 bg-gradient-to-br from-yellow-400 to-yellow-600 text-slate-950 font-black text-xl rounded-3xl hover:brightness-110 transition-all active:scale-95 shadow-2xl shadow-yellow-900/40"
                >
                  {t.premium_button}
                </button>
              </div>

              <div className="w-full lg:w-96 bg-white/5 border border-white/10 rounded-[3rem] p-10 text-center flex flex-col items-center gap-6 backdrop-blur-3xl">
                 <p className="text-slate-500 font-black uppercase tracking-[0.3em] text-xs">Access Everything</p>
                 <div className="flex flex-col items-center">
                   <p className="text-6xl font-black text-white tracking-tighter">$11</p>
                   <p className="text-slate-400 font-bold">per week</p>
                 </div>
                 <div className="w-full h-px bg-white/10 my-4"></div>
                 <div className="space-y-4 w-full">
                    <p className="text-sm font-bold text-slate-400 italic">One-click language pack downloads.</p>
                    <p className="text-xs font-medium text-slate-500">Cancel anytime. 24/7 Priority Support.</p>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="z-20 py-20 border-t border-white/5 bg-[#020617] text-center">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center border border-white/10">
               <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945" />
               </svg>
             </div>
             <span className="text-xl font-black text-white tracking-tighter">IVoice</span>
          </div>
          <p className="text-slate-600 text-[10px] font-black tracking-[0.5em] uppercase">
            &copy; 2024 IVOICE GLOBAL INTELLIGENCE &bull; ALL RIGHTS RESERVED
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-slate-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">Privacy</a>
            <a href="#" className="text-slate-500 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
