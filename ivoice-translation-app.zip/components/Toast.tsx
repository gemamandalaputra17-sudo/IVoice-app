
import React, { useEffect } from 'react';

interface ToastProps {
  message: string;
  type?: 'error' | 'success' | 'info';
  onClose: () => void;
  duration?: number;
}

const Toast: React.FC<ToastProps> = ({ message, type = 'error', onClose, duration = 5000 }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, duration);
    return () => clearTimeout(timer);
  }, [onClose, duration]);

  const bgColor = type === 'error' ? 'bg-[#ff3b30]' : type === 'success' ? 'bg-[#34c759]' : 'bg-[#007aff]';
  const icon = type === 'error' ? (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ) : (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );

  return (
    <div className="fixed top-8 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-top-8 fade-in duration-500 group">
      <div className={`${bgColor} text-white px-8 py-5 rounded-[2rem] shadow-[0_20px_50px_-10px_rgba(255,0,0,0.4)] flex items-center gap-5 border border-white/30 min-w-[320px] max-w-lg backdrop-blur-xl relative overflow-hidden`}>
        {/* Shimmer effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out pointer-events-none"></div>
        
        <span className="flex-shrink-0 bg-white/20 p-2 rounded-2xl shadow-inner border border-white/10">
          {icon}
        </span>
        <div className="flex-1 pr-4">
          <p className="text-sm font-black tracking-tight leading-tight uppercase opacity-60 mb-0.5">Engine Alert</p>
          <p className="text-base font-bold tracking-tight leading-tight">{message}</p>
        </div>
        <button 
          onClick={onClose}
          className="flex-shrink-0 hover:bg-white/20 p-2 rounded-xl transition-all active:scale-90"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Toast;
