
import React from 'react';
import { HistoryItem, SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onReplay: (text: string, locale: string) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
  motherLangCode: SupportedLanguageCode;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ 
  isOpen, 
  onClose, 
  history, 
  onReplay, 
  onDelete, 
  onClearAll,
  motherLangCode
}) => {
  const t = I18N[motherLangCode] || I18N.en;
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end animate-in fade-in duration-300">
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-lg mx-auto bg-slate-900 border-t border-slate-800 h-[85vh] rounded-t-[3rem] flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-500 safe-pb">
        <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto mt-4 mb-2"></div>
        
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-white">{t.history}</h2>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">{history.length} {t.saved_entries}</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center bg-slate-800 rounded-full text-slate-400 active:bg-slate-700"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center opacity-30">
              <svg className="w-12 h-12 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="font-black uppercase tracking-widest text-xs">{t.history_empty}</p>
            </div>
          ) : (
            history.sort((a, b) => b.timestamp - a.timestamp).map((item) => (
              <div 
                key={item.id} 
                className="bg-slate-950/50 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 active:bg-slate-800/80 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">
                    {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => handleCopy(item.translated_text, item.id)}
                      className={`p-2 rounded-lg transition-colors ${copiedId === item.id ? 'text-green-500' : 'text-slate-500 active:text-white'}`}
                    >
                      {copiedId === item.id ? (
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                        </svg>
                      )}
                    </button>
                    <button 
                      onClick={() => onReplay(item.translated_text, item.targetLangLocale)}
                      className="p-2 text-slate-500 active:text-blue-500 transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                      </svg>
                    </button>
                    <button 
                      onClick={() => onDelete(item.id)}
                      className="p-2 text-slate-500 active:text-red-500 transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="flex flex-col gap-1">
                  <p className="text-xs italic text-slate-500 line-clamp-1">"{item.original_text}"</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-white line-clamp-2">{item.translated_text}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {history.length > 0 && (
          <div className="p-6 border-t border-slate-800 bg-slate-950/30">
            <button 
              onClick={onClearAll}
              className="w-full py-4 text-xs font-black text-red-500 uppercase tracking-widest bg-red-500/10 rounded-2xl active:bg-red-500/20 transition-all border border-red-500/20"
            >
              {t.clear_history}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPanel;
