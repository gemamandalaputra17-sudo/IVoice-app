
import React, { useState, useEffect } from 'react';
import { SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface TextTranslatorProps {
  onTranslate: (text: string) => void;
  isLoading: boolean;
  disabled?: boolean;
  motherLangCode: SupportedLanguageCode;
}

const TextTranslator: React.FC<TextTranslatorProps> = ({ onTranslate, isLoading, disabled, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;
  const [text, setText] = useState('');
  const MAX_CHARS = 2000;

  const handleTranslate = () => {
    if (text.trim()) {
      onTranslate(text);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleTranslate();
    }
  };

  const handleClear = () => {
    setText('');
  };

  return (
    <div className="flex flex-col gap-4 w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="relative group">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, MAX_CHARS))}
          onKeyDown={handleKeyDown}
          disabled={isLoading || disabled}
          placeholder={t.type_placeholder}
          className="w-full h-48 bg-slate-950/60 border-2 border-slate-800 text-white rounded-[2rem] px-6 py-6 focus:outline-none focus:border-blue-500/50 transition-all resize-none placeholder:text-slate-600 font-medium text-lg shadow-inner group-hover:border-slate-700/50"
        />
        
        {/* Helper Overlays */}
        <div className="absolute top-4 right-4 flex gap-2">
          {text && !isLoading && (
            <button 
              onClick={handleClear}
              className="p-2 bg-slate-900/80 backdrop-blur-md rounded-xl text-slate-500 hover:text-white hover:bg-slate-800 transition-all active:scale-90"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        <div className="absolute bottom-6 left-6 flex items-center gap-3">
          <span className={`text-[10px] font-black tracking-widest uppercase px-3 py-1 rounded-full border ${text.length >= MAX_CHARS ? 'text-red-400 border-red-500/30' : 'text-slate-500 border-slate-800'}`}>
            {text.length} / {MAX_CHARS}
          </span>
        </div>

        <div className="absolute bottom-4 right-4 flex items-center gap-4">
          <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] hidden sm:inline-block">
            {t.ctrl_enter}
          </span>
          <button
            onClick={handleTranslate}
            disabled={isLoading || disabled || !text.trim()}
            className={`group flex items-center gap-3 px-8 py-4 rounded-[1.5rem] font-black text-sm uppercase tracking-widest transition-all active:scale-95 shadow-2xl ${
              isLoading || disabled || !text.trim()
                ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700/50'
                : 'bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-400 hover:to-indigo-500 text-white shadow-blue-500/30 border border-white/10'
            }`}
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>{t.processing}</span>
              </div>
            ) : (
              <>
                <span>{t.translate}</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TextTranslator;
