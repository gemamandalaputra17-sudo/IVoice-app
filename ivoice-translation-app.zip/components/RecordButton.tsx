
import React from 'react';
import { SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface RecordButtonProps {
  isRecording: boolean;
  isLoading: boolean;
  onStart: () => void;
  onStop: () => void;
  motherLangCode: SupportedLanguageCode;
}

const RecordButton: React.FC<RecordButtonProps> = ({ isRecording, isLoading, onStart, onStop, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;

  return (
    <div className="flex flex-col items-center justify-center py-4 relative">
      <div className="absolute -top-4 px-3 py-1 bg-blue-600/10 border border-blue-500/20 rounded-full flex items-center gap-1.5 animate-in fade-in duration-700">
        <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
        <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">{t.auto_detect}</span>
      </div>

      <button
        onPointerDown={(e) => {
          e.preventDefault();
          onStart();
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          onStop();
        }}
        onPointerLeave={(e) => {
          if (isRecording) onStop();
        }}
        disabled={isLoading}
        className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 touch-none select-none ${
          isRecording 
            ? 'bg-red-500 pulse-animation scale-105 shadow-2xl shadow-red-500/40' 
            : isLoading 
              ? 'bg-slate-800 cursor-not-allowed border border-slate-700' 
              : 'bg-blue-600 active:scale-95 shadow-xl shadow-blue-500/30'
        }`}
      >
        {isLoading ? (
          <svg className="animate-spin h-8 w-8 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : (
          <div className={`relative flex items-center justify-center ${isRecording ? 'scale-110' : ''}`}>
            {isRecording ? (
               <div className="w-8 h-8 bg-white rounded-lg animate-pulse shadow-lg"></div>
            ) : (
              <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zM17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
              </svg>
            )}
          </div>
        )}
      </button>
      <p className={`mt-4 font-black text-[10px] uppercase tracking-[0.2em] transition-colors ${isRecording ? 'text-red-400' : 'text-slate-500'}`}>
        {isRecording ? t.listening : isLoading ? t.processing : t.hold_to_speak}
      </p>
    </div>
  );
};

export default RecordButton;
