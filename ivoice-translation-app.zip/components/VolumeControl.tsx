
import React from 'react';
import { SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface VolumeControlProps {
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
  motherLangCode: SupportedLanguageCode;
}

const VolumeControl: React.FC<VolumeControlProps> = ({ value, onChange, disabled, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;

  return (
    <div className="flex flex-col gap-3 w-full max-w-xs mx-auto">
      <div className="flex justify-between items-center">
        <label className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
          {t.playback_volume}
        </label>
        <span className="text-xs font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
          {(value * 100).toFixed(0)}%
        </span>
      </div>
      <div className="relative flex items-center group">
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          disabled={disabled}
          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        />
      </div>
      <div className="flex justify-between text-[10px] text-slate-500 font-bold uppercase tracking-tighter">
        <span>{t.muted}</span>
        <span>{t.half}</span>
        <span>{t.full}</span>
      </div>
    </div>
  );
};

export default VolumeControl;
