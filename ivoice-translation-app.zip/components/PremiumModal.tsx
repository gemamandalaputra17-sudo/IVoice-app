
import React from 'react';
import { SupportedLanguageCode } from '../types';
import { I18N } from '../constants';

interface PremiumModalProps {
  onClose: () => void;
  onRestore: () => void;
  motherLangCode: SupportedLanguageCode;
}

const PremiumModal: React.FC<PremiumModalProps> = ({ onClose, onRestore, motherLangCode }) => {
  const t = I18N[motherLangCode] || I18N.en;

  const handleSubscribe = () => {
    window.open('https://www.paypal.com/ncp/payment/2KLDH9E8HAGPJ', '_blank');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-500">
      {/* Magical Background Shimmer */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-20%] w-[140%] h-[140%] bg-[conic-gradient(from_0deg,transparent_0deg,#d4af37_40deg,transparent_100deg)] opacity-10 blur-[100px] animate-[spin_8s_linear_infinite]"></div>
      </div>

      <div className="relative bg-[#1a1a1a] border border-yellow-500/30 w-full max-w-md rounded-[3rem] p-10 shadow-[0_0_80px_-20px_rgba(212,175,55,0.3)] overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Shimmering Gold Header Overlay */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-700 via-yellow-200 to-yellow-700 animate-[shimmer_2s_infinite]"></div>
        
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex flex-col items-center text-center gap-6">
          <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-700 rounded-3xl flex items-center justify-center shadow-2xl shadow-yellow-500/40 relative">
             <div className="absolute inset-0 bg-white/20 blur-md rounded-3xl animate-pulse"></div>
             <svg className="w-10 h-10 text-white relative z-10" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
             </svg>
          </div>

          <div className="space-y-2">
            <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-br from-yellow-200 to-yellow-600 tracking-tighter">
              {t.premium_title}
            </h2>
            <p className="text-slate-400 text-sm font-medium leading-relaxed px-4">
              {t.premium_desc}
            </p>
          </div>

          <div className="w-full space-y-3 py-4">
            {[t.premium_feature_1, t.premium_feature_2, t.premium_feature_3].map((f, i) => (
              <div key={i} className="flex items-center gap-3 text-left bg-white/5 p-3 rounded-2xl border border-white/5">
                <div className="w-5 h-5 rounded-full bg-yellow-500/20 flex items-center justify-center text-yellow-500 flex-shrink-0">
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-xs font-bold text-slate-300">{f}</span>
              </div>
            ))}
          </div>

          <button 
            onClick={handleSubscribe}
            className="w-full relative group py-5 bg-gradient-to-br from-yellow-400 via-yellow-200 to-yellow-600 rounded-[1.5rem] shadow-[0_15px_30px_-5px_rgba(212,175,55,0.4)] transition-all active:scale-95 overflow-hidden"
          >
            <div className="absolute inset-0 bg-white/40 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            <span className="relative z-10 text-slate-950 font-black text-sm uppercase tracking-widest">
              {t.premium_button}
            </span>
          </button>

          <button 
            onClick={onRestore}
            className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 hover:text-white transition-colors"
          >
            {t.restore_purchase}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default PremiumModal;
