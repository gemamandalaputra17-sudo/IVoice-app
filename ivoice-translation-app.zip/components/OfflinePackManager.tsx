
import React, { useState } from 'react';
import { SupportedLanguageCode, OfflinePack } from '../types';
import { I18N, SUPPORTED_LANGUAGES } from '../constants';

interface OfflinePackManagerProps {
  onDownload: (code: SupportedLanguageCode) => void;
  downloadedLangs: SupportedLanguageCode[];
  isPremium: boolean;
  motherLangCode: SupportedLanguageCode;
  onShowPremium: () => void;
}

const OfflinePackManager: React.FC<OfflinePackManagerProps> = ({ 
  onDownload, 
  downloadedLangs, 
  isPremium, 
  motherLangCode,
  onShowPremium
}) => {
  const t = I18N[motherLangCode] || I18N.en;
  const [downloading, setDownloading] = useState<SupportedLanguageCode | null>(null);

  const packs: OfflinePack[] = SUPPORTED_LANGUAGES.map(l => ({
    code: l.code,
    name: l.nativeName,
    size: l.code === 'en' || l.code === 'id' || l.code === 'es' || l.code === 'zh' ? '142 MB' : '88 MB',
    isDownloaded: downloadedLangs.includes(l.code)
  }));

  const handleDownload = (code: SupportedLanguageCode) => {
    if (!isPremium) {
      onShowPremium();
      return;
    }
    setDownloading(code);
    // Simulate neural engine indexing
    setTimeout(() => {
      onDownload(code);
      setDownloading(null);
    }, 2500);
  };

  return (
    <div className="w-full flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col gap-2 px-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-white uppercase tracking-widest">{t.download_packs}</h3>
          {!isPremium && (
            <span className="text-[9px] font-black text-yellow-500 uppercase tracking-widest bg-yellow-500/10 px-3 py-1 rounded-full border border-yellow-500/20">
              {t.premium_only}
            </span>
          )}
        </div>
        <p className="text-[10px] text-slate-500 font-medium">Download local neural models for survival translation without cellular data.</p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {packs.map((pack) => (
          <div key={pack.code} className={`group flex items-center justify-between p-5 rounded-[2rem] border transition-all duration-300 ${pack.isDownloaded ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-white/5 border-white/5 hover:border-white/10'}`}>
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner transition-transform group-hover:scale-110 ${pack.isDownloaded ? 'bg-emerald-500/10' : 'bg-white/5'}`}>
                {SUPPORTED_LANGUAGES.find(l => l.code === pack.code)?.flag}
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-black text-white uppercase tracking-tight">{pack.name}</span>
                <span className="text-[10px] text-slate-500 font-mono font-bold">{pack.size}</span>
              </div>
            </div>
            
            <button 
              disabled={pack.isDownloaded || downloading === pack.code}
              onClick={() => handleDownload(pack.code)}
              className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                pack.isDownloaded 
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' 
                  : downloading === pack.code
                    ? 'bg-slate-800 text-slate-500 animate-pulse cursor-wait'
                    : 'bg-blue-600 text-white hover:bg-blue-500 active:scale-95 shadow-lg shadow-blue-500/10'
              }`}
            >
              {pack.isDownloaded ? (
                <div className="flex items-center gap-1.5">
                   <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" /></svg>
                   {t.downloaded}
                </div>
              ) : downloading === pack.code ? t.downloading : t.download}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OfflinePackManager;
