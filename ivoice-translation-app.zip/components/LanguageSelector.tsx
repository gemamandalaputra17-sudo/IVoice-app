
import React from 'react';
import { SUPPORTED_LANGUAGES } from '../constants';
import { SupportedLanguageCode } from '../types';

interface LanguageSelectorProps {
  value: SupportedLanguageCode;
  onChange: (code: SupportedLanguageCode) => void;
  disabled?: boolean;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ value, onChange, disabled }) => {
  return (
    <div className="flex flex-col gap-1 w-full">
      <div className="relative group">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value as SupportedLanguageCode)}
          disabled={disabled}
          className="w-full bg-slate-950 border border-slate-800 text-white rounded-2xl px-5 py-4 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-bold text-sm shadow-inner disabled:opacity-50"
        >
          {SUPPORTED_LANGUAGES.map((lang) => (
            <option key={lang.code} value={lang.code}>
              {lang.flag} {lang.nativeName}
            </option>
          ))}
        </select>
        <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-blue-500">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 9l4-4 4 4m0 6l-4 4-4-4" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default LanguageSelector;
